</div> <!-- zatvara .container -->

<footer class="text-center text-white mt-5 py-3" style="background: linear-gradient(90deg, #6a0dad, #ff6f00);">
  © 2025 Music Fest. Sva prava zadržana.
</footer>

</body>
</html>

<?php session_start(); require 'dbconn.php'; // Obaveštenja o omiljenim izvođačima $notifications = []; if(isset($_SESSION['user_id'])) { $user_id = $_SESSION['user_id']; $today = date('Y-m-d'); $sql = "SELECT a.name, p.performance_time, p.stage FROM favorites f JOIN artists a ON f.artist_id = a.id JOIN program p <?php
session_start();
require 'dbconn.php';

// Obaveštenja o omiljenim izvođačima
$notifications = [];

if(isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $today = date('Y-m-d');

    $sql = "SELECT a.name, p.performance_time, p.stage
            FROM favorites f
            JOIN artists a ON f.artist_id = a.id
            JOIN program p ON a.id = p.artist_id
            WHERE f.user_id = ? AND DATE(p.performance_time) = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $user_id, $today);
    $stmt->execute();
    $result = $stmt->get_result();

    while($row = $result->fetch_assoc()) {
        $notifications[] = "{$row['name']} – " . date("H:i", strtotime($row['performance_time'])) . " ({$row['stage']})";
    }
}

// Uzimamo prvi festival
$festival = $conn->query("SELECT * FROM festivals LIMIT 1")->fetch_assoc();

// --- NOVO: PRETRAGA IZVOĐAČA ---
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

if ($search !== '') {
    // Ako korisnik pretražuje izvođače
    $sql = "SELECT p.*, a.name AS artist_name, a.genre, a.id AS artist_id
            FROM program p
            JOIN artists a ON p.artist_id = a.id
            WHERE p.festival_id = {$festival['id']}
              AND a.name LIKE '%" . $conn->real_escape_string($search) . "%'
            ORDER BY p.performance_time";
} else {
    // Ako nema pretrage, prikazujemo sve izvođače
    $sql = "SELECT p.*, a.name AS artist_name, a.genre, a.id AS artist_id
            FROM program p
            JOIN artists a ON p.artist_id = a.id
            WHERE p.festival_id = {$festival['id']}
            ORDER BY p.performance_time";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="sr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($festival['name']); ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body class="container mt-4">

<?php if(!empty($notifications)): ?>
    <div class="alert alert-info">
        🎶 Danas nastupaju tvoji omiljeni izvođači:<br>
        <?php foreach($notifications as $note): ?>
            • <?php echo htmlspecialchars($note); ?><br>
        <?php endforeach; ?>
    </div>
<?php endif; ?>


<h1><?php echo htmlspecialchars($festival['name']); ?> - <?php echo htmlspecialchars($festival['location']); ?></h1>
<p><?php echo htmlspecialchars($festival['description']); ?></p>

<!-- Gornji deo: Moji omiljeni + Login -->
<div class="d-flex justify-content-between align-items-center mb-3">
    <?php if(isset($_SESSION['user_id'])): ?>
        <a href="favorites_list.php" class="btn btn-outline-primary">❤️ Moji omiljeni</a>
    <?php endif; ?>

    <?php if(isset($_SESSION['username'])): ?>
        <p class="mb-0">Prijavljeni ste kao: <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong> | 
        <a href="logout.php">Logout</a></p>
    <?php else: ?>
        <p class="mb-0">
            <a href="login.php" class="btn btn-sm btn-outline-success">Login</a>
            <a href="register.php" class="btn btn-sm btn-outline-secondary">Registracija</a>
        </p>
    <?php endif; ?>
</div>

<!-- 🔍 Pretraga izvođača -->
<form method="get" class="mb-3" style="max-width:400px;">
    <div class="input-group">
        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" class="form-control" placeholder="Pretraži izvođače...">
        <button type="submit" class="btn btn-primary">🔍 Traži</button>
    </div>
</form>

<?php if($search !== ''): ?>
    <a href="index.php" class="btn btn-outline-secondary btn-sm mb-3">Poništi pretragu</a>
<?php endif; ?>

<h2>Program:</h2>
<table class="table table-striped">
    <thead>
        <tr>
            <th>Vreme</th>
            <th>Izvođač</th>
            <th>Žanr</th>
            <th>Scena</th>
            <th>Omiljeni</th>
        </tr>
    </thead>
    <tbody>
    <?php if($result->num_rows > 0): ?>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['performance_time']); ?></td>
            <td>
                <a href="artist.php?id=<?php echo $row['artist_id']; ?>">
                    <?php echo htmlspecialchars($row['artist_name']); ?>
                </a>
            </td>
            <td><?php echo htmlspecialchars($row['genre']); ?></td>
            <td><?php echo htmlspecialchars($row['stage']); ?></td>
            <td>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <form method="post" action="favorite.php">
                        <input type="hidden" name="artist_id" value="<?php echo $row['artist_id']; ?>">
                        <button type="submit" name="favorite" class="btn btn-sm btn-outline-danger">❤️ Dodaj</button>
                    </form>
                <?php else: ?>
                    <span class="text-muted">Login za dodavanje</span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr><td colspan="5" class="text-center text-muted">Nema izvođača koji odgovaraju pretrazi.</td></tr>
    <?php endif; ?>
    </tbody>
</table>

<hr>
<h3>Kupovina / Rezervacija ulaznica</h3>

<?php if(isset($_SESSION['user_id'])): ?>
<form method="post" action="tickets.php" class="mt-3" style="max-width:300px;">
    <input type="hidden" name="festival_id" value="<?php echo $festival['id']; ?>">
    <label for="quantity" class="form-label">Broj ulaznica:</label>
    <input type="number" name="quantity" id="quantity" class="form-control mb-2" min="1" max="10" required>
    <button type="submit" class="btn btn-success w-100">🎫 Kupi ulaznice</button>
</form>
<?php else: ?>
    <p class="text-muted">Prijavite se da biste kupili ulaznice.</p>
<?php endif; ?>

<?php
// Anketa
$poll = $conn->query("SELECT * FROM polls ORDER BY created_at DESC LIMIT 1")->fetch_assoc();
if($poll):
    $poll_id = $poll['id'];
    $options = $conn->query("SELECT * FROM poll_options WHERE poll_id=$poll_id");
?>
<hr>
<h4>🗳️ Anketa: <?php echo htmlspecialchars($poll['question']); ?></h4>
<form method="post" action="vote.php">
    <input type="hidden" name="poll_id" value="<?php echo $poll_id; ?>">
    <?php while($opt = $options->fetch_assoc()): ?>
        <div>
            <label>
                <input type="radio" name="option_id" value="<?php echo $opt['id']; ?>" required>
                <?php echo htmlspecialchars($opt['option_text']); ?>
            </label>
        </div>
    <?php endwhile; ?>
    <button type="submit" class="btn btn-success mt-2">Glasaj</button>
</form>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
